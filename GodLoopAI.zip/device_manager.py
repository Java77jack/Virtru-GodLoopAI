class SmartLight:
    def __init__(self, location):
        self.location = location

    def check_and_act(self):
        print(f"[{self.location}] SmartLight is ON if needed.")

class SmartCamera:
    def __init__(self, location):
        self.location = location

    def check_and_act(self):
        print(f"[{self.location}] SmartCamera scanning area.")